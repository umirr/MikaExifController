from html import escape
import re
from pathlib import Path
import sys
import os
import ctypes
import json
import unicodedata
from datetime import datetime
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, as_completed

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QListWidget, QListWidgetItem, QLabel, QPushButton, QComboBox,
    QLineEdit, QSplitter, QFileDialog, QMessageBox, QFrame, QTextEdit,
    QCheckBox, QTabWidget, QStackedWidget, QPlainTextEdit, QInputDialog, QStyleOptionButton
)
from PyQt6.QtCore import (
    Qt, QSize, QTimer, QThread, pyqtSignal,
    QPropertyAnimation, pyqtProperty
)
from PyQt6.QtGui import (
    QPixmap, QImage, QIcon, QDragEnterEvent,
    QDropEvent, QPainter, QColor, QPalette
)


# ============================================================
# Windows 작업 표시줄 아이콘 분리
# ============================================================

try:
    myappid = "mika.exifremover.pro.1.0"
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
except Exception:
    pass


# ============================================================
# PyInstaller 리소스 경로
# ============================================================

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


APP_DIR = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
CONFIG_FILE = APP_DIR / "config.json"


def read_rules_text(path):
    data = Path(path).read_bytes()
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp949")



# ============================================================
# 라이트 모드
# ============================================================

LIGHT_QSS = """
QWidget {
    background-color: #f8f9fa;
    color: #1f2937;
    font-family: '맑은 고딕', sans-serif;
    font-size: 13px;
}

QSplitter::handle {
    background-color: #e5e7eb;
    margin: 2px;
}

QSplitter::handle:hover {
    background-color: #3b82f6;
}

QFrame.cardFrame {
    background-color: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 8px;
}

QLabel.sectionTitle {
    font-weight: bold;
    font-size: 14px;
    color: #374151;
    margin-bottom: 6px;
}

QListWidget {
    background-color: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    outline: none;
}

QListWidget::item {
    border-radius: 6px;
    padding: 6px;
    margin-bottom: 2px;
}

QListWidget::item:hover {
    background-color: #f3f4f6;
}

QListWidget::item:selected {
    background-color: #e0f2fe;
    color: #0369a1;
    font-weight: bold;
}

#previewLabel {
    background-color: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #9ca3af;
    font-size: 14px;
}

#dropArea {
    background-color: #eff6ff;
    border: 2px dashed #93c5fd;
    border-radius: 8px;
    color: #1d4ed8;
    font-weight: bold;
    font-size: 13px;
}

QTextEdit#logArea {
    background-color: #f9fafb;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 6px;
    font-family: 'Consolas', '맑은 고딕', monospace;
    font-size: 11px;
}

QLineEdit, QComboBox {
    background-color: #ffffff;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 6px;
}

QLineEdit:read-only {
    background-color: #f3f4f6;
    color: #6b7280;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QCheckBox {
    font-size: 12px;
    color: #374151;
    font-weight: bold;
    margin-top: 4px;
    margin-bottom: 4px;
}

QPushButton {
    background-color: #e5e7eb;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    font-weight: bold;
    color: #374151;
}

QPushButton:hover {
    background-color: #d1d5db;
}

QPushButton:disabled {
    background-color: #f3f4f6;
    color: #9ca3af;
}

QPushButton#accentButton {
    background-color: #3b82f6;
    color: #ffffff;
}

QPushButton#accentButton:hover {
    background-color: #2563eb;
}

QPushButton#accentButton:disabled {
    background-color: #93c5fd;
    color: #ffffff;
}

QScrollBar:vertical {
    border: none;
    background: transparent;
    width: 8px;
    margin: 2px;
}

QScrollBar::handle:vertical {
    background: #cbd5e1;
    min-height: 24px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #94a3b8;
}

QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical {
    height: 0px;
    background: none;
}

QScrollBar:horizontal {
    border: none;
    background: transparent;
    height: 8px;
    margin: 2px;
}

QScrollBar::handle:horizontal {
    background: #cbd5e1;
    min-width: 24px;
    border-radius: 4px;
}

QScrollBar::handle:horizontal:hover {
    background: #94a3b8;
}

QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal {
    width: 0px;
    background: none;
}
"""


# ============================================================
# 다크 모드
# ============================================================

DARK_QSS = """
QWidget {
    background-color: #1B1B1B;
    color: #E0E0E0;
    font-family: '맑은 고딕', sans-serif;
    font-size: 13px;
}

QSplitter::handle {
    background-color: #2D2D2D;
    margin: 2px;
}

QSplitter::handle:hover {
    background-color: #888888;
}

QFrame.cardFrame {
    background-color: #242424;
    border: 1px solid #333333;
    border-radius: 8px;
    padding: 8px;
}

QLabel.sectionTitle {
    font-weight: bold;
    font-size: 14px;
    color: #FFFFFF;
    margin-bottom: 6px;
}

QListWidget {
    background-color: #242424;
    border: 1px solid #333333;
    border-radius: 8px;
    outline: none;
    color: #E0E0E0;
}

QListWidget::item {
    border-radius: 6px;
    padding: 6px;
    margin-bottom: 2px;
}

QListWidget::item:hover {
    background-color: #333333;
}

QListWidget::item:selected {
    background-color: #444444;
    color: #FFFFFF;
    font-weight: bold;
}

#previewLabel {
    background-color: #1B1B1B;
    border: 1px solid #333333;
    border-radius: 8px;
    color: #aaaaaa;
    font-size: 14px;
}

#dropArea {
    background-color: #242424;
    border: 2px dashed #555555;
    border-radius: 8px;
    color: #CCCCCC;
    font-weight: bold;
    font-size: 13px;
}

QTextEdit#logArea {
    background-color: #121212;
    border: 1px solid #333333;
    border-radius: 6px;
    padding: 6px;
    font-family: 'Consolas', '맑은 고딕', monospace;
    font-size: 11px;
    color: #D4D4D4;
}

QLineEdit, QComboBox {
    background-color: #121212;
    border: 1px solid #333333;
    border-radius: 6px;
    padding: 6px;
    color: #E0E0E0;
}

QLineEdit:read-only {
    background-color: #242424;
    color: #aaaaaa;
}

QComboBox QAbstractItemView {
    background-color: #242424;
    color: #E0E0E0;
    selection-background-color: #444444;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QCheckBox {
    font-size: 12px;
    color: #E0E0E0;
    font-weight: bold;
    margin-top: 4px;
    margin-bottom: 4px;
}

QPushButton {
    background-color: #333333;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    font-weight: bold;
    color: #E0E0E0;
}

QPushButton:hover {
    background-color: #444444;
}

QPushButton:disabled {
    background-color: #242424;
    color: #aaaaaa;
}

QPushButton#accentButton {
    background-color: #E0E0E0;
    color: #1B1B1B;
}

QPushButton#accentButton:hover {
    background-color: #FFFFFF;
}

QPushButton#accentButton:disabled {
    background-color: #404040;
    color: #cccccc;
}

QScrollBar:vertical {
    border: none;
    background: transparent;
    width: 8px;
    margin: 2px;
}

QScrollBar::handle:vertical {
    background: #444444;
    min-height: 24px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #666666;
}

QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical {
    height: 0px;
    background: none;
}

QScrollBar:horizontal {
    border: none;
    background: transparent;
    height: 8px;
    margin: 2px;
}

QScrollBar::handle:horizontal {
    background: #444444;
    min-width: 24px;
    border-radius: 4px;
}

QScrollBar::handle:horizontal:hover {
    background: #666666;
}

QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal {
    width: 0px;
    background: none;
}
"""


# ============================================================
# 토글 스위치
# ============================================================

def font_control_style(background, foreground, hover):
    return f"""
    QFrame#fontSizePill {{ background: {background}; border: none; border-radius: 6px; }}
    QFrame#fontSizePill QLabel {{ background: transparent; color: {foreground}; font-weight: bold; }}
    QFrame#fontSizePill QPushButton {{
        background: transparent; color: {foreground}; border: 1px solid transparent;
        border-radius: 4px; padding: 0; font-family: "Segoe UI"; font-size: 16px;
    }}
    QFrame#fontSizePill QPushButton:hover, QFrame#fontSizePill QPushButton:pressed {{ background: {hover}; }}
    QFrame#fontSizePill QPushButton:focus {{ border-color: {foreground}; }}
    """


LIGHT_QSS += font_control_style("#e5e7eb", "#374151", "#d1d5db")
DARK_QSS += font_control_style("#333333", "#E0E0E0", "#444444")


DARK_QSS += """
QLabel#rulesStatus { color: #b5bdc8; }
QLineEdit, QPlainTextEdit { placeholder-text-color: #aaaaaa; selection-background-color: #415778; selection-color: white; }
"""
LIGHT_QSS += "QLabel#rulesStatus { color: #566172; }"


def menu_style(surface, text, hover, selected, selected_text):
    return f"""
    QTabWidget::pane {{ border: none; padding-top: 8px; background: {surface}; }}
    QTabBar {{ background: {surface}; border: none; }}
    QTabBar::tab {{
        background: {surface}; color: {text}; border: none; border-radius: 6px;
        padding: 6px 12px; margin: 2px; font-weight: bold;
    }}
    QTabBar::tab:hover {{ background: {hover}; }}
    QTabBar::tab:selected {{ background: {selected}; color: {selected_text}; }}
    """


LIGHT_QSS += menu_style("#f8f9fa", "#4b5563", "#eef0f3", "#e5e7eb", "#374151")
DARK_QSS += menu_style("#1b1b1b", "#cccccc", "#292929", "#333333", "#e0e0e0")


class FontStepButton(QPushButton):
    def __init__(self, step, description):
        super().__init__()
        self.step = step
        self.setAccessibleName(description)
        self.setToolTip(description)
        self.setFixedWidth(30)
        self.setSizePolicy(self.sizePolicy().Policy.Fixed, self.sizePolicy().Policy.Expanding)

    def paintEvent(self, event):
        super().paintEvent(event)
        option = QStyleOptionButton()
        self.initStyleOption(option)
        color = option.palette.color(QPalette.ColorRole.ButtonText)
        painter = QPainter(self)
        painter.translate(self.width() / 2, self.height() / 2)
        painter.fillRect(-5, -1, 10, 2, color)
        if self.step > 0:
            painter.fillRect(-1, -5, 2, 10, color)


class ToggleSwitch(QWidget):

    toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setFixedSize(50, 26)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self._checked = False
        self._circle_position = 3

        self.animation = QPropertyAnimation(
            self,
            b"circle_position"
        )

        self.animation.setDuration(150)

    @pyqtProperty(int)
    def circle_position(self):
        return self._circle_position

    @circle_position.setter
    def circle_position(self, pos):
        self._circle_position = pos
        self.update()

    def isChecked(self):
        return self._checked

    def setChecked(self, checked, animate=True):

        self._checked = checked

        end_pos = 27 if checked else 3

        if animate:

            self.animation.stop()
            self.animation.setEndValue(end_pos)
            self.animation.start()

        else:

            self._circle_position = end_pos
            self.update()

    def mousePressEvent(self, event):

        if event.button() == Qt.MouseButton.LeftButton:

            self.setChecked(
                not self._checked
            )

            self.toggled.emit(
                self._checked
            )

    def paintEvent(self, event):

        painter = QPainter(self)

        painter.setRenderHint(
            QPainter.RenderHint.Antialiasing
        )

        bg_color = (
            QColor("#E0E0E0")
            if self._checked
            else QColor("#444444")
        )

        painter.setBrush(bg_color)
        painter.setPen(Qt.PenStyle.NoPen)

        painter.drawRoundedRect(
            0,
            0,
            self.width(),
            self.height(),
            13,
            13
        )

        painter.setBrush(
            QColor("#ffffff")
        )

        painter.drawEllipse(
            self._circle_position,
            3,
            20,
            20
        )


# ============================================================
# 이미지 처리 Worker
# ============================================================

class ProcessWorker(QThread):

    log_signal = pyqtSignal(str, str)
    finished_signal = pyqtSignal(int, int, str)

    def __init__(
        self,
        file_paths,
        save_dir_path,
        format_text,
        rules
    ):

        super().__init__()

        self.file_paths = file_paths
        self.save_dir_path = save_dir_path
        self.format_text = format_text
        self.rules = rules

    # --------------------------------------------------------
    # 규칙 비교용 정규화
    # --------------------------------------------------------

    @staticmethod
    def _normalize_for_match(text):
        """
        파일명 비교 전용 정규화.

        중요:
        - 중간 공백을 삭제하지 않음
        - '-' 삭제하지 않음
        - '_' 삭제하지 않음
        - 괄호 삭제하지 않음
        - 한글 Unicode를 NFC로 통일
        - 영문 대소문자 무시
        - 양끝 공백만 제거

        따라서:

            "69 강" != "69강"

        이지만

            파일: 69 강-3a80b9.png
            규칙: 69 강=115

        은 부분 일치한다.
        """

        if text is None:
            return ""

        if not isinstance(text, str):
            text = str(text)

        text = unicodedata.normalize(
            "NFC",
            text
        )

        text = text.casefold()

        return text.strip()

    # --------------------------------------------------------
    # 파일명 규칙 검색
    # --------------------------------------------------------

    def _find_matching_rule(
        self,
        file_name,
        orig_name
    ):
        """
        우선순위:

        1. 확장자 포함 완전 정확 일치
        2. 확장자 제외 완전 정확 일치
        3. NFC + 대소문자 무시 정확 일치
        4. NFC + 대소문자 무시 부분 일치
        5. 여러 부분 규칙이 걸리면 가장 긴 규칙 우선
        """

        # ----------------------------------------------------
        # 1. 원본 문자열 그대로 정확 일치
        # ----------------------------------------------------

        if file_name in self.rules:

            return (
                file_name,
                self.rules[file_name],
                "정확 일치"
            )

        if orig_name in self.rules:

            return (
                orig_name,
                self.rules[orig_name],
                "정확 일치"
            )

        # ----------------------------------------------------
        # 2. 비교용 파일명 생성
        # ----------------------------------------------------

        normalized_file = (
            self._normalize_for_match(
                file_name
            )
        )

        normalized_orig = (
            self._normalize_for_match(
                orig_name
            )
        )

        # ----------------------------------------------------
        # 3. 정규화 정확 일치
        # ----------------------------------------------------

        for key, value in self.rules.items():

            normalized_key = (
                self._normalize_for_match(
                    key
                )
            )

            if not normalized_key:
                continue

            if normalized_key == normalized_file:

                return (
                    key,
                    value,
                    "정확 일치"
                )

            if normalized_key == normalized_orig:

                return (
                    key,
                    value,
                    "정확 일치"
                )

        # ----------------------------------------------------
        # 4. 부분 일치
        # ----------------------------------------------------

        matches = []

        for key, value in self.rules.items():

            normalized_key = (
                self._normalize_for_match(
                    key
                )
            )

            if not normalized_key:
                continue

            if (
                normalized_key in normalized_file
                or
                normalized_key in normalized_orig
            ):

                matches.append(
                    (
                        key,
                        value,
                        normalized_key
                    )
                )

        # ----------------------------------------------------
        # 5. 여러 개가 걸렸다면 가장 긴 규칙 우선
        # ----------------------------------------------------

        if matches:

            best_key, best_value, best_normalized = max(
                matches,
                key=lambda x: len(x[2])
            )

            return (
                best_key,
                best_value,
                "부분 일치"
            )

        return (
            None,
            None,
            None
        )

    # --------------------------------------------------------
    # 이미지 한 장 처리
    # --------------------------------------------------------

    def _process_one(self, file_path):

        file_name = os.path.basename(
            file_path
        )

        try:

            img = Image.open(
                file_path
            )

            fmt_map = {
                "원본 유지": None,
                "JPG": "JPEG",
                "PNG": "PNG",
                "WEBP": "WEBP"
            }

            target_fmt = fmt_map.get(
                self.format_text
            )

            # ------------------------------------------------
            # EXIF 제거용 새 이미지 생성
            # ------------------------------------------------

            if (
                target_fmt == "JPEG"
                and img.mode in ("RGBA", "P")
            ):

                img = img.convert(
                    "RGB"
                )

            else:

                data = list(
                    img.getdata()
                )

                clean_img = Image.new(
                    img.mode,
                    img.size
                )

                clean_img.putdata(
                    data
                )

                img = clean_img

            # ------------------------------------------------
            # 저장 경로
            # ------------------------------------------------

            orig_dir, _ = os.path.split(
                file_path
            )

            if self.save_dir_path:

                target_dir = (
                    self.save_dir_path
                )

            else:

                target_dir = orig_dir

            # ------------------------------------------------
            # 원본 이름 / 확장자
            # ------------------------------------------------

            orig_name, orig_ext = (
                os.path.splitext(
                    file_name
                )
            )

            # ------------------------------------------------
            # 출력 확장자
            # ------------------------------------------------

            if target_fmt is None:

                out_ext = orig_ext

            elif self.format_text == "JPG":

                out_ext = ".jpg"

            else:

                out_ext = (
                    f".{self.format_text.lower()}"
                )

            # ------------------------------------------------
            # 규칙 검색
            # ------------------------------------------------

            (
                matched_key,
                new_val,
                match_type
            ) = self._find_matching_rule(
                file_name,
                orig_name
            )

            # ------------------------------------------------
            # 규칙이 없으면 원본 이름
            # ------------------------------------------------

            if new_val is None:

                new_val = orig_name

            else:

                # 결과값의 양끝 공백만 제거
                new_val = new_val.strip()

            # ------------------------------------------------
            # 새 파일명
            # ------------------------------------------------

            val_base, val_ext = (
                os.path.splitext(
                    new_val
                )
            )

            valid_image_exts = (
                ".jpg",
                ".jpeg",
                ".png",
                ".webp",
                ".tiff"
            )

            if (
                val_ext.lower()
                in valid_image_exts
            ):

                new_file_name = (
                    new_val
                )

            else:

                new_file_name = (
                    f"{new_val}{out_ext}"
                )

            # ------------------------------------------------
            # 저장
            # ------------------------------------------------

            save_path = os.path.join(
                target_dir,
                new_file_name
            )

            img.save(
                save_path,
                format=target_fmt
            )

            # ------------------------------------------------
            # 로그용 매칭 정보
            # ------------------------------------------------

            if matched_key is not None:

                match_info = (
                    f"{match_type}: "
                    f"'{matched_key}' "
                    f"→ '{new_val}'"
                )

            else:

                match_info = (
                    "규칙 없음"
                )

            return (
                True,
                file_name,
                new_file_name,
                "",
                target_dir,
                match_info
            )

        except Exception as e:

            return (
                False,
                file_name,
                "",
                str(e),
                "",
                ""
            )

    # --------------------------------------------------------
    # 전체 실행
    # --------------------------------------------------------

    def run(self):

        self.log_signal.emit(
            "--- 병렬 EXIF 제거 작업 시작 ---",
            "info"
        )

        success_cnt = 0
        fail_cnt = 0
        last_target_dir = ""

        max_workers = min(
            32,
            (os.cpu_count() or 4) + 4
        )

        with ThreadPoolExecutor(
            max_workers=max_workers
        ) as executor:

            futures = [
                executor.submit(
                    self._process_one,
                    path
                )
                for path in self.file_paths
            ]

            for future in as_completed(
                futures
            ):

                (
                    success,
                    file_name,
                    new_file_name,
                    err,
                    target_dir,
                    match_info
                ) = future.result()

                if success:

                    success_cnt += 1

                    last_target_dir = (
                        target_dir
                    )

                    if (
                        match_info
                        != "규칙 없음"
                    ):

                        self.log_signal.emit(
                            (
                                f"[성공] "
                                f"{file_name} "
                                f"→ {new_file_name} "
                                f"({match_info})"
                            ),
                            "success"
                        )

                    else:

                        self.log_signal.emit(
                            (
                                f"[성공] "
                                f"{file_name} "
                                f"→ {new_file_name} "
                                f"(일치 규칙 없음)"
                            ),
                            "success"
                        )

                else:

                    fail_cnt += 1

                    self.log_signal.emit(
                        (
                            f"[예외] "
                            f"{file_name} "
                            f"(사유: {err})"
                        ),
                        "error"
                    )

        self.log_signal.emit(
            (
                f"--- 작업 종료 "
                f"(성공: {success_cnt}건, "
                f"예외: {fail_cnt}건) ---"
            ),
            "info"
        )

        self.finished_signal.emit(
            success_cnt,
            fail_cnt,
            last_target_dir
        )


# ============================================================
# 드래그 앤 드롭 영역
# ============================================================

class DropAreaLabel(QLabel):

    def __init__(
        self,
        parent=None,
        on_files_dropped=None
    ):

        super().__init__(parent)

        self.on_files_dropped = (
            on_files_dropped
        )

        self.setAcceptDrops(
            True
        )

        self.setText(
            "여기로 이미지를 Drag & Drop 해줘!"
        )

        self.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.setObjectName(
            "dropArea"
        )

    def dragEnterEvent(
        self,
        event: QDragEnterEvent
    ):

        if event.mimeData().hasUrls():

            event.acceptProposedAction()

    def dropEvent(
        self,
        event: QDropEvent
    ):

        urls = (
            event.mimeData().urls()
        )

        file_paths = [
            url.toLocalFile()
            for url in urls
            if url.isLocalFile()
        ]

        if (
            file_paths
            and self.on_files_dropped
        ):

            self.on_files_dropped(
                file_paths
            )


# ============================================================
# 메인 프로그램
# ============================================================

class ExifRemoverProQt(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "미카의 EXIF 컨트롤러"
        )

        # ----------------------------------------------------
        # 프로그램 아이콘
        # ----------------------------------------------------

        icon_path = resource_path(
            "my_icon.ico"
        )

        if os.path.exists(
            icon_path
        ):

            self.setWindowIcon(
                QIcon(icon_path)
            )

        self.resize(
            1150,
            700
        )

        self.setMinimumSize(
            900,
            550
        )

        # ----------------------------------------------------
        # 상태값
        # ----------------------------------------------------

        self.file_paths = []

        self.current_pil_image = (
            None
        )

        self.rules_file_path = ""

        self.save_dir_path = ""

        self.worker = None

        # ----------------------------------------------------
        # 미리보기 리사이즈 타이머
        # ----------------------------------------------------

        self._resize_timer = QTimer()

        self._resize_timer.setSingleShot(
            True
        )

        self._resize_timer.timeout.connect(
            self._render_preview
        )

        # ----------------------------------------------------
        # 초기화
        # ----------------------------------------------------

        self.log_entries = []
        self.presets = {"기본 규칙": ""}
        self.active = "기본 규칙"
        self.font_size = 15
        self.loading = True
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self._save_config)
        self._init_ui()

        self._load_config()
        self._refresh_presets()
        self.loading = False

        self._update_rules_status()

        self.log(
            "프로그램이 실행되었어!"
        )

    # ========================================================
    # UI
    # ========================================================

    def _init_ui(self):

        central_widget = QWidget()

        tabs = QTabWidget()
        tabs.tabBar().setDrawBase(False)
        frame = QWidget()
        frame_layout = QVBoxLayout(frame)
        frame_layout.setContentsMargins(12, 8, 12, 12)
        frame_layout.addWidget(tabs)
        self.setCentralWidget(frame)
        self.tabs = tabs
        self.convert_stack = QStackedWidget()
        self.convert_stack.addWidget(DropAreaLabel(on_files_dropped=self.add_files))
        self.convert_stack.addWidget(central_widget)
        tabs.addTab(self.convert_stack, "이미지 변환")
        tabs.addTab(self._editor_page(), "규칙 편집")

        main_layout = QVBoxLayout(
            central_widget
        )

        main_layout.setContentsMargins(
            12,
            12,
            12,
            12
        )

        main_layout.setSpacing(
            10
        )

        # ----------------------------------------------------
        # 상단 영역
        # ----------------------------------------------------

        top_bar_layout = QHBoxLayout()

        self.drop_area = DropAreaLabel(
            on_files_dropped=self.add_files
        )

        self.drop_area.setFixedHeight(
            75
        )

        top_bar_layout.addWidget(
            self.drop_area,
            stretch=1
        )

        # ----------------------------------------------------
        # 테마 스위치
        # ----------------------------------------------------

        theme_widget = QWidget()
        theme_layout = QHBoxLayout(theme_widget)
        theme_layout.setContentsMargins(6, 0, 0, 0)

        theme_layout.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.theme_label = QLabel(
            "🌙 다크 모드"
        )

        self.theme_label.setStyleSheet(
            "font-weight: bold; font-size: 11px;"
        )

        self.dark_switch = (
            ToggleSwitch()
        )

        self.dark_switch.toggled.connect(
            self._on_theme_toggled
        )

        theme_layout.addWidget(
            self.theme_label,
            alignment=Qt.AlignmentFlag.AlignCenter
        )

        theme_layout.addWidget(
            self.dark_switch,
            alignment=Qt.AlignmentFlag.AlignCenter
        )

        tabs.setCornerWidget(theme_widget, Qt.Corner.TopRightCorner)

        main_layout.addLayout(
            top_bar_layout
        )

        # ----------------------------------------------------
        # 메인 Splitter
        # ----------------------------------------------------

        splitter = QSplitter(
            Qt.Orientation.Horizontal
        )

        main_layout.addWidget(
            splitter,
            stretch=1
        )

        # ====================================================
        # 왼쪽 - 이미지 목록
        # ====================================================

        left_frame = QFrame()

        left_frame.setProperty(
            "class",
            "cardFrame"
        )

        left_layout = QVBoxLayout(
            left_frame
        )

        left_layout.setContentsMargins(
            8,
            8,
            8,
            8
        )

        lbl_list_title = QLabel(
            "이미지 목록"
        )

        lbl_list_title.setProperty(
            "class",
            "sectionTitle"
        )

        left_layout.addWidget(
            lbl_list_title
        )

        self.file_list = QListWidget()

        self.file_list.setIconSize(
            QSize(
                60,
                60
            )
        )

        self.file_list.currentRowChanged.connect(
            self._on_item_selected
        )

        left_layout.addWidget(
            self.file_list
        )

        splitter.addWidget(
            left_frame
        )

        # ====================================================
        # 중앙 - 이미지 미리보기
        # ====================================================

        center_frame = QFrame()

        center_frame.setProperty(
            "class",
            "cardFrame"
        )

        center_layout = QVBoxLayout(
            center_frame
        )

        center_layout.setContentsMargins(
            8,
            8,
            8,
            8
        )

        lbl_preview_title = QLabel(
            "이미지 미리보기"
        )

        lbl_preview_title.setProperty(
            "class",
            "sectionTitle"
        )

        center_layout.addWidget(
            lbl_preview_title,
            stretch=0
        )

        self.preview_label = QLabel(
            "목록에서 이미지를 선택하면\n"
            "여기에 크게 표시돼!"
        )

        self.preview_label.setObjectName(
            "previewLabel"
        )

        self.preview_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        center_layout.addWidget(
            self.preview_label,
            stretch=1
        )

        splitter.addWidget(
            center_frame
        )

        # ====================================================
        # 오른쪽
        # ====================================================

        right_frame = QFrame()

        right_frame.setProperty(
            "class",
            "cardFrame"
        )

        right_layout = QVBoxLayout(
            right_frame
        )

        right_layout.setContentsMargins(
            8,
            8,
            8,
            8
        )

        # ----------------------------------------------------
        # 저장 경로
        # ----------------------------------------------------

        right_layout.addWidget(
            QLabel("저장 경로")
        )

        dir_layout = QHBoxLayout()

        self.dir_entry = QLineEdit()

        self.dir_entry.setPlaceholderText(
            "원본 파일과 같은 폴더"
        )

        self.dir_entry.setReadOnly(
            True
        )

        dir_layout.addWidget(
            self.dir_entry
        )

        btn_dir = QPushButton(
            "찾아보기"
        )

        btn_dir.clicked.connect(
            self.select_dir
        )

        dir_layout.addWidget(
            btn_dir
        )

        right_layout.addLayout(
            dir_layout
        )

        # ----------------------------------------------------
        # 규칙 파일
        # ----------------------------------------------------

        right_layout.addWidget(
            QLabel(
                "파일명 규칙"
            )
        )

        self.convert_picker = QComboBox()
        self.convert_picker.currentIndexChanged.connect(lambda: self._select(self.convert_picker))
        right_layout.addWidget(self.convert_picker)
        self.rules_status_label = QLabel(
            "규칙 미지정"
        )

        self.rules_status_label.setObjectName("rulesStatus")
        self.rules_status_label.setStyleSheet(
            "font-size: 11px;"
        )

        right_layout.addWidget(
            self.rules_status_label
        )

        # ----------------------------------------------------
        # 변환 포맷
        # ----------------------------------------------------

        right_layout.addWidget(
            QLabel("변환 포맷")
        )

        self.format_combo = QComboBox()

        self.format_combo.addItems(
            [
                "원본 유지",
                "JPG",
                "PNG",
                "WEBP"
            ]
        )

        right_layout.addWidget(
            self.format_combo
        )

        # ----------------------------------------------------
        # 완료 후 폴더 열기
        # ----------------------------------------------------

        self.open_folder_chk = QCheckBox(
            "작업 완료 시 저장 폴더 열기"
        )

        self.open_folder_chk.setChecked(
            True
        )

        self.open_folder_chk.stateChanged.connect(
            self._save_config
        )

        right_layout.addWidget(
            self.open_folder_chk
        )

        # ----------------------------------------------------
        # 로그
        # ----------------------------------------------------

        right_layout.addWidget(
            QLabel("작업 로그")
        )

        self.log_area = QTextEdit()

        self.log_area.setObjectName(
            "logArea"
        )

        self.log_area.setReadOnly(
            True
        )

        right_layout.addWidget(
            self.log_area,
            stretch=1
        )

        # ----------------------------------------------------
        # 버튼
        # ----------------------------------------------------

        btn_layout = QHBoxLayout()

        self.clear_btn = QPushButton(
            "목록 비우기"
        )

        self.clear_btn.clicked.connect(
            self.clear_list
        )

        self.run_btn = QPushButton(
            "EXIF 제거 실행"
        )

        self.run_btn.setObjectName(
            "accentButton"
        )

        self.run_btn.clicked.connect(
            self.process_files
        )

        btn_layout.addWidget(
            self.clear_btn
        )

        btn_layout.addWidget(
            self.run_btn
        )

        right_layout.addLayout(
            btn_layout
        )

        splitter.addWidget(
            right_frame
        )

        # ----------------------------------------------------
        # 비율
        # ----------------------------------------------------

        splitter.setStretchFactor(
            0,
            1
        )

        splitter.setStretchFactor(
            1,
            3
        )

        splitter.setStretchFactor(
            2,
            1
        )

    # ========================================================
    # 테마
    # ========================================================

    def _on_theme_toggled(
        self,
        is_dark
    ):

        app = QApplication.instance()

        if is_dark:

            app.setStyleSheet(
                DARK_QSS
            )

        else:

            app.setStyleSheet(
                LIGHT_QSS
            )

        self.log_area.clear()
        for entry in self.log_entries:
            self._append_log(*entry)
        self._save_config()

    # ========================================================
    # 로그
    # ========================================================

    def log(
        self,
        message,
        level="info"
    ):

        now = datetime.now().strftime(
            "%H:%M:%S"
        )

        entry = (now, message, level)
        self.log_entries.append(entry)
        self._append_log(*entry)

    def _append_log(self, now, message, level):
        is_dark = (
            self.dark_switch.isChecked()
        )

        color_map = {

            "info":
                "#94a3b8"
                if is_dark
                else "#4b5563",

            "success":
                "#34d399"
                if is_dark
                else "#10b981",

            "error":
                "#f87171"
                if is_dark
                else "#ef4444",

            "warning":
                "#fbbf24"
                if is_dark
                else "#f59e0b"
        }

        color = color_map.get(
            level,
            (
                "#f1f5f9"
                if is_dark
                else "#1f2937"
            )
        )

        timestamp_color = "#a3adba" if is_dark else "#556070"
        html_msg = (
            f'<span style="color: {timestamp_color};">'
            f'[{now}]'
            f'</span> '
            f'<span style="color: {color}; '
            f'font-weight: bold;">'
            f'{escape(message)}'
            f'</span>'
        )

        self.log_area.append(
            html_msg
        )

    # ========================================================
    # 창 리사이즈
    # ========================================================

    def resizeEvent(
        self,
        event
    ):

        super().resizeEvent(
            event
        )

        if self.current_pil_image:

            self._resize_timer.start(
                30
            )

    # ========================================================
    # 이미지 추가
    # ========================================================

    def add_files(
        self,
        paths
    ):

        valid_exts = (
            ".jpg",
            ".jpeg",
            ".png",
            ".webp",
            ".tiff"
        )

        added_cnt = 0

        for path in paths:

            if (
                path.lower().endswith(
                    valid_exts
                )
                and
                path not in self.file_paths
            ):

                self.file_paths.append(
                    path
                )

                self._add_list_item(
                    path
                )

                added_cnt += 1

            elif not path.lower().endswith(
                valid_exts
            ):

                self.log(
                    (
                        "[예외] 지원하지 않는 형식 "
                        f"({os.path.basename(path)})"
                    ),
                    "warning"
                )

        if added_cnt > 0:
            self.convert_stack.setCurrentIndex(1)

            self.log(
                f"{added_cnt}개 이미지 파일 추가 완료",
                "info"
            )

            if (
                self.file_list.currentRow()
                == -1
            ):

                self.file_list.setCurrentRow(
                    0
                )

    # ========================================================
    # 목록 썸네일
    # ========================================================

    def _add_list_item(
        self,
        file_path
    ):

        try:

            img = Image.open(
                file_path
            )

            img.thumbnail(
                (
                    120,
                    120
                )
            )

            if img.mode != "RGBA":

                img = img.convert(
                    "RGBA"
                )

            data = img.tobytes(
                "raw",
                "RGBA"
            )

            qimg = QImage(
                data,
                img.size[0],
                img.size[1],
                QImage.Format.Format_RGBA8888
            )

            pixmap = (
                QPixmap.fromImage(
                    qimg
                )
            )

            item = QListWidgetItem(
                QIcon(pixmap),
                os.path.basename(
                    file_path
                )
            )

            self.file_list.addItem(
                item
            )

        except Exception as e:

            self.log(
                (
                    "[예외] 썸네일 실패 "
                    f"({os.path.basename(file_path)}): "
                    f"{e}"
                ),
                "error"
            )

    # ========================================================
    # 이미지 선택
    # ========================================================

    def _on_item_selected(
        self,
        row
    ):

        if (
            row < 0
            or
            row >= len(self.file_paths)
        ):

            return

        file_path = (
            self.file_paths[row]
        )

        try:

            self.current_pil_image = (
                Image.open(file_path)
            )

            self._render_preview()

        except Exception as e:

            self.current_pil_image = (
                None
            )

            self.preview_label.setText(
                f"미리보기 오류:\n{e}"
            )

    # ========================================================
    # 미리보기
    # ========================================================

    def _render_preview(self):

        if not self.current_pil_image:

            return

        w = (
            self.preview_label.width()
            - 10
        )

        h = (
            self.preview_label.height()
            - 10
        )

        if (
            w <= 10
            or
            h <= 10
        ):

            return

        try:

            img = (
                self.current_pil_image.copy()
            )

            img.thumbnail(
                (
                    w,
                    h
                ),
                Image.Resampling.LANCZOS
            )

            if img.mode != "RGBA":

                img = img.convert(
                    "RGBA"
                )

            data = img.tobytes(
                "raw",
                "RGBA"
            )

            qimg = QImage(
                data,
                img.size[0],
                img.size[1],
                QImage.Format.Format_RGBA8888
            )

            pixmap = (
                QPixmap.fromImage(
                    qimg
                )
            )

            self.preview_label.setPixmap(
                pixmap
            )

        except Exception as e:

            print(
                f"미리보기 렌더링 실패: {e}"
            )

    # ========================================================
    # 저장 폴더 선택
    # ========================================================

    def select_dir(self):

        path = (
            QFileDialog.getExistingDirectory(
                self,
                "저장 폴더 선택"
            )
        )

        if path:

            self.save_dir_path = path

            self.dir_entry.setText(
                path
            )

            self.log(
                f"저장 경로 변경: {path}"
            )

    # ========================================================
    # 규칙 파일 선택
    # ========================================================

    def _editor_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        row = QHBoxLayout()
        layout.addLayout(row)
        row.addWidget(QLabel("규칙 목록"))
        self.editor_picker = QComboBox()
        self.editor_picker.currentIndexChanged.connect(lambda: self._select(self.editor_picker))
        row.addWidget(self.editor_picker, 1)
        def button(bar, title, action):
            btn = QPushButton(title)
            btn.clicked.connect(action)
            bar.addWidget(btn)
            return btn
        button(row, "새 규칙", self._new_preset)
        button(row, "제목 변경", self._rename_preset)
        button(row, "삭제", self._delete_preset)
        button(row, "TXT 불러오기", self._import_text)
        button(row, "TXT 내보내기", self._export_text)
        bar = QHBoxLayout()
        layout.addLayout(bar)
        button(bar, "전체 순서 지정", lambda: self._renumber(False))
        button(bar, "빈공간 자동 채우기", lambda: self._renumber(True))
        button(bar, "전체 복사", lambda: QApplication.clipboard().setText(self.editor.toPlainText()))
        pill = QFrame()
        pill.setObjectName("fontSizePill")
        pill.setToolTip("글자 크기 조절")
        halves = QHBoxLayout(pill)
        halves.setContentsMargins(10, 0, 4, 0)
        halves.setSpacing(0)
        caption = QLabel("글자 크기")
        caption.setContentsMargins(2, 0, 6, 0)
        halves.addWidget(caption)
        for step, description in ((-1, "글자 작게"), (1, "글자 크게")):
            btn = FontStepButton(step, description)
            btn.clicked.connect(lambda checked=False, delta=step: self._resize_font(delta))
            halves.addWidget(btn)
        pill.setSizePolicy(pill.sizePolicy().Policy.Preferred, pill.sizePolicy().Policy.Expanding)
        bar.addWidget(pill)
        bar.addStretch()
        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText("한 줄에 하나씩 입력하세요. 예: A=1 (A.png → 1.png)")
        self.editor.textChanged.connect(self._edited)
        layout.addWidget(self.editor, 1)
        self.save_status = QLabel("편집한 규칙은 자동 저장됩니다.")
        layout.addWidget(self.save_status)
        return page

    def _refresh_presets(self):
        for picker in (self.convert_picker, self.editor_picker):
            picker.blockSignals(True)
            picker.clear()
            picker.addItems(self.presets.keys())
            picker.setCurrentText(self.active)
            picker.blockSignals(False)
        self.editor.blockSignals(True)
        self.editor.setPlainText(self.presets[self.active])
        self.editor.blockSignals(False)
        self.editor.setStyleSheet(f"font-size: {self.font_size}px;")
        self._update_rules_status()

    def _select(self, picker):
        name = picker.currentText()
        if name in self.presets and name != self.active:
            self.active = name
            self._refresh_presets()
            self._save_config()

    def _add_preset(self, name, content):
        self.active = name
        self.presets[name] = content
        self._refresh_presets()
        self._save_config()

    def _new_preset(self):
        name, ok = QInputDialog.getText(self, "새 규칙", "규칙 이름")
        name = name.strip()
        if ok and name:
            if name in self.presets:
                QMessageBox.warning(self, "새 규칙", "이미 사용 중인 이름입니다.")
            else:
                self._add_preset(name, "")

    def _rename_preset(self):
        name, ok = QInputDialog.getText(self, "제목 변경", "새 규칙 제목", text=self.active)
        name = name.strip()
        if not ok or not name or name == self.active:
            return
        if name in self.presets:
            QMessageBox.warning(self, "제목 변경", "이미 사용 중인 제목입니다.")
            return
        self.presets = {name if key == self.active else key: value for key, value in self.presets.items()}
        self.active = name
        self._refresh_presets()
        self._save_config()

    def _delete_preset(self):
        choice = QMessageBox.question(self, "규칙 삭제", f"‘{self.active}’ 규칙을 삭제할까요?",
                                      QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                      QMessageBox.StandardButton.No)
        if choice != QMessageBox.StandardButton.Yes:
            return
        index = self.editor_picker.currentIndex()
        del self.presets[self.active]
        if not self.presets:
            self.presets["기본 규칙"] = ""
        self.active = list(self.presets)[min(index, len(self.presets) - 1)]
        self._refresh_presets()
        self._save_config()

    def _import_text(self):
        path, _ = QFileDialog.getOpenFileName(self, "TXT 불러오기", "", "텍스트 파일 (*.txt);;모든 파일 (*)")
        if not path:
            return
        try:
            content = read_rules_text(path)
        except (OSError, UnicodeError) as exc:
            QMessageBox.warning(self, "불러오기 실패", str(exc))
            return
        base = Path(path).stem
        name = base
        index = 2
        while name in self.presets:
            name = f"{base} ({index})"
            index += 1
        self._add_preset(name, content)

    def _export_text(self):
        path, _ = QFileDialog.getSaveFileName(self, "TXT 내보내기", self.active + ".txt", "텍스트 파일 (*.txt)")
        if path:
            try:
                Path(path).write_text(self.editor.toPlainText(), encoding="utf-8")
            except OSError as exc:
                QMessageBox.warning(self, "내보내기 실패", str(exc))

    def _edited(self):
        self.presets[self.active] = self.editor.toPlainText()
        self.save_status.setText("저장 중…")
        self.save_timer.start(350)

    def _resize_font(self, change):
        self.font_size = max(10, min(40, self.font_size + change))
        self.editor.setStyleSheet(f"font-size: {self.font_size}px;")
        self._save_config()

    def _renumber(self, numbered_only):
        lines = self.editor.toPlainText().split("\n")
        number = 0
        for index, line in enumerate(lines):
            entry = line.strip()
            if not entry or entry.startswith("#"):
                continue
            if entry.startswith("(") and entry.endswith(")") and "=" in entry:
                entry = entry[1:-1]
            key, sep, value = (part.strip() for part in entry.partition("="))
            if numbered_only and not (sep and value.isdecimal()):
                continue
            if sep and key.isdecimal() and value and not value.isdecimal():
                # Convert an old numbered prefix when numbering the whole list.
                key = value
            if not key:
                continue
            number += 1
            lines[index] = f"{key}={number}"
        cursor = self.editor.textCursor()
        cursor.select(cursor.SelectionType.Document)
        cursor.insertText("\n".join(lines))

    def _load_config(self):
        legacy = APP_DIR / "config.json"
        path = CONFIG_FILE if CONFIG_FILE.exists() else legacy
        cfg = {}
        if path.exists():
            try:
                cfg = json.loads(path.read_text(encoding="utf-8-sig"))
            except (OSError, ValueError) as exc:
                QMessageBox.warning(self, "설정 읽기 실패", str(exc))
        if cfg.get("presets"):
            self.presets = cfg["presets"]
            active = cfg.get("active")
            self.active = active if active in self.presets else next(iter(self.presets))
        else:
            rule_path = APP_DIR / (cfg.get("rules_file_path") or "rules.txt")
            if rule_path.is_file():
                try:
                    self.presets[self.active] = read_rules_text(rule_path)
                except (OSError, UnicodeError) as exc:
                    QMessageBox.warning(self, "이전 규칙 읽기 실패", str(exc))
        self.font_size = cfg.get("font_size", 15)
        self.open_folder_chk.setChecked(cfg.get("open_folder_after", True))
        dark = cfg.get("dark_mode", False)
        self.dark_switch.setChecked(dark, animate=False)
        QApplication.instance().setStyleSheet(DARK_QSS if dark else LIGHT_QSS)

    def _save_config(self):
        if self.loading:
            return
        cfg = dict(presets=self.presets, active=self.active, font_size=self.font_size,
                   open_folder_after=self.open_folder_chk.isChecked(), dark_mode=self.dark_switch.isChecked())
        from PyQt6.QtCore import QSaveFile, QIODevice
        try:
            CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
            file = QSaveFile(str(CONFIG_FILE))
            data = json.dumps(cfg, ensure_ascii=False, indent=2).encode("utf-8")
            if not file.open(QIODevice.OpenModeFlag.WriteOnly) or file.write(data) != len(data) or not file.commit():
                raise OSError(file.errorString())
            self.save_status.setText("저장됨")
        except OSError as exc:
            self.save_status.setText(f"저장 실패: {exc}")
            return False
        self._update_rules_status()
        return True

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "이미지 변환", "작업이 끝난 뒤 닫아 주세요.")
            event.ignore()
        elif self._save_config():
            super().closeEvent(event)
        else:
            QMessageBox.warning(self, "저장 실패", self.save_status.text())
            event.ignore()

    def _load_rules(self):
        rules = {}
        for line in self.presets[self.active].splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("(") and line.endswith(")"):
                line = line[1:-1]
            key, sep, value = line.partition("=")
            if sep and key.strip():
                rules[unicodedata.normalize("NFC", key.strip())] = unicodedata.normalize("NFC", value.strip())
        return rules

    def _update_rules_status(self):
        count = len(self._load_rules())
        self.rules_status_label.setText(f"{count}개 규칙 적용" if count else "규칙 없음 · 기존 파일명 유지")

    def clear_list(self):

        self.convert_stack.setCurrentIndex(0)
        self.file_paths.clear()

        self.file_list.clear()

        self.current_pil_image = (
            None
        )

        self.preview_label.clear()

        self.preview_label.setText(
            (
                "목록에서 이미지를 선택하면\n"
                "여기에 크게 표시돼!"
            )
        )

        self.log(
            "목록을 비웠어."
        )

    # ========================================================
    # 처리 시작
    # ========================================================

    def process_files(self):

        if not self.file_paths:

            QMessageBox.warning(
                self,
                "알림",
                "처리할 이미지 파일이 없어!"
            )

            return

        # ----------------------------------------------------
        # 규칙 로드
        # ----------------------------------------------------

        rules = (
            self._load_rules()
        )

        self._update_rules_status()

        # ----------------------------------------------------
        # 버튼 잠금
        # ----------------------------------------------------

        self.run_btn.setEnabled(
            False
        )

        self.clear_btn.setEnabled(
            False
        )

        # ----------------------------------------------------
        # Worker
        # ----------------------------------------------------

        self.worker = ProcessWorker(
            self.file_paths,
            self.save_dir_path,
            self.format_combo.currentText(),
            rules
        )

        self.worker.log_signal.connect(
            self.log
        )

        self.worker.finished_signal.connect(
            self._on_process_finished
        )

        self.worker.start()

    # ========================================================
    # 작업 완료
    # ========================================================

    def _on_process_finished(
        self,
        success_cnt,
        fail_cnt,
        last_target_dir
    ):

        self.run_btn.setEnabled(
            True
        )

        self.clear_btn.setEnabled(
            True
        )

        QMessageBox.information(
            self,
            "완료",
            (
                f"총 {success_cnt}개 작업 완료! "
                f"(예외 {fail_cnt}건)"
            )
        )

        # ----------------------------------------------------
        # 저장 폴더 자동 열기
        # ----------------------------------------------------

        if (
            success_cnt > 0
            and
            self.open_folder_chk.isChecked()
            and
            last_target_dir
            and
            os.path.exists(
                last_target_dir
            )
        ):

            try:

                os.startfile(
                    last_target_dir
                )

                self.log(
                    (
                        "저장 폴더 열기: "
                        f"{last_target_dir}"
                    ),
                    "info"
                )

            except Exception as e:

                self.log(
                    (
                        "[예외] 폴더 열기 실패: "
                        f"{e}"
                    ),
                    "warning"
                )


# ============================================================
# 실행
# ============================================================

if __name__ == "__main__":

    app = QApplication(
        sys.argv
    )

    app.setStyleSheet(
        LIGHT_QSS
    )

    window = (
        ExifRemoverProQt()
    )

    window.show()

    sys.exit(
        app.exec()
    )